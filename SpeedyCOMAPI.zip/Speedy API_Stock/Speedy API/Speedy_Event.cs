﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SpeedyAPI;

namespace Speedy_API
{
    partial class Form1
    {
        NewOrderMessage OrderNew()
        {
            NewOrderMessage NewMsg = new NewOrderMessage();
            NewMsg.AE = textBox1.Text;
            NewMsg.Account = textBox2.Text;
            NewMsg.Symbol = textBox4.Text;
            NewMsg.OrderType = (cmbOrdType.Items[cmbOrdType.SelectedIndex] as OrdTypeCmbItem).Value;
            NewMsg.PositionEffect = PositionEffectEnum.peOpen;
            NewMsg.Price = Convert.ToDouble(textBox5.Text);
            NewMsg.Side = (cmbSide.Items[cmbSide.SelectedIndex] as SideCmbItem).Value;
            NewMsg.TradingSessionID = (cmbSession.Items[cmbSession.SelectedIndex] as SessionCmbItem).Value;
            NewMsg.OrderQty = Convert.ToInt32(textBox6.Text);
            NewMsg.Market = (cmbMarket.Items[cmbMarket.SelectedIndex] as MarketCmbItem).Value;
            NewMsg.TSEStockSeqNo = 0;
            NewMsg.TSEOrderType = ((int)(cmbTSE.Items[cmbTSE.SelectedIndex] as TSEOrdTypeCmbItem).Value).ToString();
            NewMsg.TimeInForce = (cmbTIF.Items[cmbTIF.SelectedIndex] as TIFCmbItem).Value;
            //NewMsg.NID = 0; //if NID=0→Server auto generate
            NewMsg.NID = FOrderConnection.GenerateUniqueID(FNewOrderMsg.Market, MessageTypeEnum.mtNew);
            //NewMsg.Data =   //GIGO;

            return NewMsg;
        }

        CancelOrderMessage OrderCancel(ShowOrderStatus SOS)
        {
            CancelOrderMessage CancelMsg = new CancelOrderMessage();
            CancelMsg.OrderID = SOS.OrderID;
            CancelMsg.Market = (MarketEnum)Enum.Parse(typeof(MarketEnum), SOS.Market, false);
            CancelMsg.Account = SOS.Account;
            CancelMsg.ExchangeCode = SOS.Exchange;
            CancelMsg.Symbol = SOS.Symbol;
            CancelMsg.Price = SOS.OrdPrice;
            CancelMsg.Side = (SideEnum)Enum.Parse(typeof(SideEnum), SOS.Side, false);
            CancelMsg.OrderType = (OrderTypeEnum)Enum.Parse(typeof(OrderTypeEnum), SOS.OrderType, false);
            CancelMsg.TradingSessionID = (TradingSessionIDEnum)Enum.Parse(typeof(TradingSessionIDEnum), SOS.TradeSession, false);
            CancelMsg.Data = SOS.Data;
            CancelMsg.NID = 0;
            //CancelMsg.NID = FOrderConnection.GenerateUniqueID(FNewOrderMsg.Market, MessageTypeEnum.mtCancel);
            return CancelMsg;
        }

        public void OrderReplace(ShowOrderStatus SOS, int _Qty, double _Px)
        {
            ReplaceOrderMessage RpOrdMsg = new ReplaceOrderMessage();
            RpOrdMsg.Market = (MarketEnum)Enum.Parse(typeof(MarketEnum), SOS.Market, false);
            RpOrdMsg.Account = SOS.Account;
            RpOrdMsg.OrderID = SOS.OrderID;
            RpOrdMsg.ExchangeCode = SOS.Exchange;
            RpOrdMsg.Symbol = SOS.Symbol;
            RpOrdMsg.BrokerID = SOS.BrokerID;
            RpOrdMsg.Side = (SideEnum)Enum.Parse(typeof(SideEnum), SOS.Side, false);
            RpOrdMsg.PositionEffect = PositionEffectEnum.peOpen;
            RpOrdMsg.Data = SOS.Data;
            RpOrdMsg.OrderType = (OrderTypeEnum)Enum.Parse(typeof(OrderTypeEnum), SOS.OrderType, false);
            RpOrdMsg.OrderQty = _Qty;       //Amend Price→Qty = 0
            RpOrdMsg.Price = _Px;           //Amend Qty→Px = 0;     
            RpOrdMsg.TimeInForce = (TimeInForceEnum)Enum.Parse(typeof(TimeInForceEnum), SOS.TimeInForce, false);
            RpOrdMsg.NID = 0;
            //RpOrdMsg.NID = FOrderConnection.GenerateUniqueID(FNewOrderMsg.Market, MessageTypeEnum.mtReplace);

            FOrderConnection.ReplaceOrder(RpOrdMsg);
        }

        void FOrderConnection_OnRecoverFinished(int Count)
        {

        }

        void FOrderConnection_OnDisconnected()
        {
            button1.Enabled = true;
            button3.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            label4.Text = "Speedy Disconnected";
        }

        void FOrderConnection_OnLogonReply(string ReplyMessage, SpeedyAPI.LogonResultEnum Result, int ConnectionID)
        {
            if (Result == LogonResultEnum.lrOK)
            {
                FConnectionID = ConnectionID;
                label4.Text = "登入成功";
                //查詢回報
                FRecoverCount = 0;
                string RecoverTime = "08:30:00";
                string RecoverDate = DateTime.Now.ToString("yyyyMMdd");
                FOrderConnection.Recover3(RecoverDate, RecoverTime, RecoverTypeEnum.rtAll, RecoverMarketEnum.rmAll, RecoverSessionEnum.rsAll);
                button1.Enabled = false;
                button2.Enabled = true;
                button3.Enabled = true;
                button4.Enabled = true;
                button5.Enabled = true;

            }
            else
            {
                label4.Text = "登入失敗:" + ReplyMessage;
                button1.Enabled = true;
                button2.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
                button5.Enabled = false;
            }
        }

        void FOrderConnection_OnConnected()
        {
            button1.Enabled = true;
            
        }

        void FOrderConnection_OnExecutionReport(SpeedyAPI.ExecutionReportMessage Msg, SpeedyAPI.ExecDupEnum PossDup)
        {
            if (PossDup == SpeedyAPI.ExecDupEnum.edPossibleDuplicate || PossDup == SpeedyAPI.ExecDupEnum.edSpeedyGenerate)
            {
                FRecoverCount++;
            }
            else
            {
                if (Msg.ConnectionID != FConnectionID)
                {
                }
            }
            if (Msg.ExecType == ExecTypeEnum.etOrderStatus)
            {
                OnOrderStatus(Msg);
                return;
            }
            switch (Msg.OrderStatus)
            {
                case OrderStatusEnum.osPendingNew: OnPendingNew(Msg); break;
                case OrderStatusEnum.osPendingCancel: OnPendingCancel(Msg); break;
                case OrderStatusEnum.osPendingReplace: OnPendingReplace(Msg); break;
                case OrderStatusEnum.osNew: OnNewOrder(Msg); break;///< Order confirm from Exchange.                             
                case OrderStatusEnum.osFilled:
                case OrderStatusEnum.osPartiallyFilled: OnPartiallyFilled(Msg.OrderID, Msg.NID, Msg.OrderQty, Msg.Side, Msg.Price, Msg.Data, Msg.TransactTime); break;
                case OrderStatusEnum.osReplaced: OnReplaced(Msg); break;
                case OrderStatusEnum.osCanceled: OnCanceled(Msg); break;
                case OrderStatusEnum.osRejected: OnRejected(Msg); break;
                default: break;
            }
        }
    }
}
