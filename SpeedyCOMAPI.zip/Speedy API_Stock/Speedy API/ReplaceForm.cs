﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SpeedyAPI;

namespace Speedy_API
{
    public partial class ReplaceForm : Form
    {
        ShowOrderStatus SOS = null;
        Form1 fr1 = null;
        int ori_qty = 0;
        public ReplaceForm(ShowOrderStatus _SOS, Form1 _fr1)
        {
            InitializeComponent();
            SOS = _SOS;
            fr1 = _fr1;
        }

        private void ReplaceForm_Load(object sender, EventArgs e)
        {
            OrderTypeEnum orderType = (OrderTypeEnum)Enum.Parse(typeof(OrderTypeEnum), SOS.OrderType, false);
            TimeInForceEnum timeInForceEnum = (TimeInForceEnum)Enum.Parse(typeof(TimeInForceEnum), SOS.TimeInForce, false);

            bool isLimitROD = (orderType == OrderTypeEnum.otLimit && timeInForceEnum == TimeInForceEnum.tifROD);
            bool isPartialFilled = !(SOS.CumQty == 0);
            if (!isLimitROD)
            {
                tabControl1.TabPages.Remove(tabPage2);
            }
            
            textBox1.Text = SOS.OrdPrice.ToString();
            
            textBox2.Text = (SOS.Qty - SOS.CumQty - 1).ToString();
            ori_qty = (SOS.Qty - SOS.CumQty - 1);
            if (ori_qty == 0) tabControl1.TabPages.Remove(tabPage1);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int Qty = 0;
            double Px = 0;
            switch (tabControl1.SelectedTab.Text)
            {
                case "Amend Qty":
                    {
                        Qty = int.Parse(textBox2.Text);
                        if (ori_qty == 0)
                        {
                            MessageBox.Show("無剩餘量不可改單");
                            return;
                        }
                        else if (Qty > ori_qty)
                        {
                            MessageBox.Show("刪除量不可>剩餘量");
                            return;
                              
                        }
                    }
                    break;
                case "Amend Px":
                    {
                        if ((OrderTypeEnum)Enum.Parse(typeof(OrderTypeEnum), SOS.OrderType, false) == OrderTypeEnum.otMarket)
                        {
                            MessageBox.Show("市價單不可改價");
                            return;
                        }
                        Px = Convert.ToDouble(textBox1.Text);
                    }
                    break;
            }
            
            fr1.OrderReplace(SOS, Qty, Px);
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
