﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SpeedyAPI;

namespace Speedy_API
{
    public partial class Form1 : Form
    {
        OrderConnection FOrderConnection = null;
        NewOrderMessage FNewOrderMsg = null;
        int FConnectionID = -1;
        
        BindingList<ShowOrderStatus> showOrderStatuses = new BindingList<ShowOrderStatus>();
        Dictionary<long, int> FNID = new Dictionary<long, int>();
        Dictionary<string, int> FOrdID = new Dictionary<string, int>();
        int FRecoverCount;
        public Form1()
        {
            InitializeComponent();
            FOrderConnection = new OrderConnection();
            FNewOrderMsg = new  NewOrderMessage();
            FOrderConnection.OnConnected += new IOrderConnectionEvents_OnConnectedEventHandler(FOrderConnection_OnConnected);
            FOrderConnection.OnLogonReply += new IOrderConnectionEvents_OnLogonReplyEventHandler(FOrderConnection_OnLogonReply);
            FOrderConnection.OnExecutionReport += new IOrderConnectionEvents_OnExecutionReportEventHandler(FOrderConnection_OnExecutionReport);
            FOrderConnection.OnRecoverFinished += new SpeedyAPI.IOrderConnectionEvents_OnRecoverFinishedEventHandler(FOrderConnection_OnRecoverFinished);
            FOrderConnection.OnDisconnected += new SpeedyAPI.IOrderConnectionEvents_OnDisconnectedEventHandler(FOrderConnection_OnDisconnected);
            FOrderConnection.Create2("OrderClient@" + System.Net.Dns.GetHostName());    //有用Windows Message機制做同步,可於事件中直接Update UI
            //FOrderConnection.CreateMT("OrderClient@" + System.Net.Dns.GetHostName());     //Update UI需Invoke
            String LogFileName = "SpeedyOrderClient_" + System.DateTime.Now.Date.Year.ToString() + "_" + System.DateTime.Now.Date.Month.ToString() + "_" + System.DateTime.Now.Date.Day.ToString() + ".log";
            FOrderConnection.SetDebugLog(LogFileName);
            FOrderConnection.SetBrokerID(MarketEnum.mTSE, "9A95");
            FOrderConnection.EnablePandingNewAck = false;       //don't reply Ack like FIX Pending Msg
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FOrderConnection.Connect2("128.110.5.67", 23456, 2);
            setCmb();
            dataGridView1.DataSource = showOrderStatuses;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FOrderConnection.Logon(textBox1.Text, textBox3.Text, textBox2.Text, ConnectionTypeEnum.ctBoth);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            NewOrderMessage NewMsg = OrderNew();
            AddNewOrderRow(NewMsg);
            FOrderConnection.NewOrder(NewMsg);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FOrderConnection.Disconnect();
        }

        private void cmbOrdType_SelectedIndexChanged(object sender, EventArgs e)
        {
            OrderTypeEnum oEnum = (cmbOrdType.Items[cmbOrdType.SelectedIndex] as OrdTypeCmbItem).Value;
            switch (oEnum)
            {
                case OrderTypeEnum.otLimit:
                    textBox5.Text = "";
                    textBox5.Enabled = true;
                    break;
                case OrderTypeEnum.otMarket:
                    textBox5.Text = "0";
                    textBox5.Enabled = false;
                    break;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            amend_func(AmendTypeEnum.cancel);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            amend_func(AmendTypeEnum.amend);
        }
    }
}
