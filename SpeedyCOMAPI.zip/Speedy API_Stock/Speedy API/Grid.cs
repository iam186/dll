﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SpeedyAPI;

namespace Speedy_API
{
    
    public class ShowOrderStatus : INotifyPropertyChanged
    {
        private string _AE;
        private string _Broker;
        private string _Acct;
        private string _Exh;
        private string _Symbol;
        private string _OrdID;
        private string _Side;
        private double _OrdPrice;
        private double _AvgPrice;
        private int _Qty;
        private int _CumQty;
        private string _OrdType;
        private string _Market;
        private string _Text;
        private string _OrdStatus;
        private string _TradeSession;
        private string _TIF;
        private long _NID;
        private string _Data;
        private string _OrderTime;
        private string _DealTime;
        private double _Amt;

        [DisplayName("AE")]
        public string AE { get { return _AE; } set { _AE = value; } }
        [DisplayName("BrokerID")]
        public string BrokerID { get { return _Broker; } set { _Broker = value; OnPropertyChanged("_Broker"); } }

        [DisplayName("Account")]
        public string Account { get { return _Acct; } set { _Acct = value; } }
        [DisplayName("Exchange")]
        public string Exchange { get { return _Exh; } set { _Exh = value; } }
        [DisplayName("Symbol")]
        public string Symbol { get { return _Symbol; } set { _Symbol = value; } }
        [DisplayName("Order ID")]
        public string OrderID { get { return _OrdID; } set { _OrdID = value; OnPropertyChanged("_OrdID"); } }
        [DisplayName("Side")]
        public string Side { get { return _Side; } set { _Side = value; } }
        [DisplayName("OrdPrice")]
        public double OrdPrice { get { return _OrdPrice; } set { _OrdPrice = value; OnPropertyChanged("_OrdPrice"); } }
        [DisplayName("AvgPrice")]
        public double AvgPrice { get { return _AvgPrice; } set { _AvgPrice = value; OnPropertyChanged("_AvgPrice"); } }
        [DisplayName("Qty")]
        public int Qty { get { return _Qty; } set { _Qty = value; OnPropertyChanged("_Qty"); } }
        [DisplayName("CumQty")]
        public int CumQty { get { return _CumQty; } set { _CumQty = value; OnPropertyChanged("_CumQty"); } }
        [DisplayName("OrderType")]
        public string OrderType { get { return _OrdType; } set { _OrdType = value; } }
        [DisplayName("Market")]
        public string Market { get { return _Market; } set { _Market = value; } }
        [DisplayName("Text")]
        public string Text { get { return _Text; } set { _Text = value; OnPropertyChanged("_Text"); } }
        [DisplayName("OrderStatus")]
        public string OrderStatus { get { return _OrdStatus; } set { _OrdStatus = value; OnPropertyChanged("_OrdStatus"); } }
        [DisplayName("TradeSession")]
        public string TradeSession { get { return _TradeSession; } set { _TradeSession = value; } }
        [DisplayName("TimeInForce")]
        public string TimeInForce { get { return _TIF; } set { _TIF = value; OnPropertyChanged("_TIF"); } }
        [DisplayName("NID")]
        public long NID { get { return _NID; } set { _NID = value; } }
        [DisplayName("Data")]
        public string Data { get { return _Data; } set { _Data = value; OnPropertyChanged("_Data"); } }
        [DisplayName("OrderTime")]
        public string OrderTime { get { return _OrderTime; } set { _OrderTime = value; OnPropertyChanged("_OrderTime"); } }
        [DisplayName("DealTime")]
        public string DealTime { get { return _DealTime; } set { _DealTime = value; OnPropertyChanged("_DealTime"); } }


        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }

        public double calculate_amt(int qty, double price)
        {
            _Amt += (qty * price);
            return _Amt;
        }
    }
    partial class Form1
    {
        //下單新Row
        void AddNewOrderRow(NewOrderMessage NewMsg)
        {
            ShowOrderStatus SOS = new ShowOrderStatus();
            SOS.AE = NewMsg.AE;
            SOS.Account = NewMsg.Account;
            SOS.Exchange = NewMsg.ExchangeCode;
            SOS.Symbol = NewMsg.Symbol;
            SOS.OrderID = "";
            SOS.Side = NewMsg.Side.ToString();
            SOS.OrdPrice = NewMsg.Price;
            SOS.AvgPrice = 0;
            SOS.Qty = NewMsg.OrderQty;
            SOS.CumQty = 0;
            SOS.OrderType = NewMsg.OrderType.ToString();
            SOS.Market = NewMsg.Market.ToString();
            SOS.Text = "";
            SOS.OrderStatus = OrderStatusEnum.osPendingNew.ToString();
            SOS.TradeSession = NewMsg.TradingSessionID.ToString();
            SOS.TimeInForce = NewMsg.TimeInForce.ToString();
            SOS.NID = NewMsg.NID;
            SOS.Data = NewMsg.Data;
            
            if (!FNID.ContainsKey(NewMsg.NID)) FNID.Add(NewMsg.NID, showOrderStatuses.Count);
            showOrderStatuses.Add(SOS);
        }
        //回報新Row
        void AddNewRowByNewOrderExecutionReport(ExecutionReportMessage Msg)
        {
            ShowOrderStatus SOS = new ShowOrderStatus();
            SOS.AE = Msg.AE;
            SOS.BrokerID = Msg.BrokerID;
            SOS.Account = Msg.Account;
            SOS.Exchange = Msg.ExchangeCode;
            SOS.Symbol = Msg.Symbol;
            SOS.OrderID = Msg.OrderID;
            SOS.Side = Msg.Side.ToString();
            SOS.OrdPrice = Msg.Price;
            SOS.AvgPrice = 0;
            SOS.Qty = Msg.OrderQty;
            SOS.CumQty = 0;
            SOS.OrderType = Msg.OrderType.ToString();
            SOS.Market = Msg.Market.ToString();
            SOS.Text = "";
            SOS.OrderStatus = Msg.OrderStatus.ToString();
            SOS.TradeSession = Msg.TradingSessionID.ToString();
            SOS.TimeInForce = Msg.TimeInForce.ToString();
            SOS.NID = Msg.NID;
            if (Msg.Data != null) SOS.Data = Msg.Data;
            if (Msg.NID != 0 && !FNID.ContainsKey(Msg.NID)) FNID.Add(Msg.NID, showOrderStatuses.Count);
            if (Msg.OrderID.Length > 0 && !FOrdID.ContainsKey(Msg.OrderID)) FOrdID.Add(Msg.OrderID, showOrderStatuses.Count);
            showOrderStatuses.Add(SOS);
        }

        void OnOrderStatus(ExecutionReportMessage Msg)
        {
            if (FNID.ContainsKey(Msg.NID))
            {
                int idx = FNID[Msg.NID];
                showOrderStatuses[idx].Symbol = Msg.Symbol;
                showOrderStatuses[idx].OrderID = Msg.OrderID;
                showOrderStatuses[idx].Data = Msg.Data;
                showOrderStatuses[idx].OrderStatus = Msg.OrderStatus.ToString();
                showOrderStatuses[idx].Text = "OrderStatus";
            }
        }
        //委託傳送中
        void OnPendingNew(ExecutionReportMessage Msg)
        {
            if (FNID.ContainsKey(Msg.NID))
            {
                int idx = FNID[Msg.NID];
                showOrderStatuses[idx].OrderStatus = OrderStatusEnum.osPendingNew.ToString();
                if (Msg.Data != null) showOrderStatuses[idx].Data = Msg.Data;
            }
        }
        //刪單傳送中
        void OnPendingCancel(ExecutionReportMessage Msg)
        {
            if (FNID.ContainsKey(Msg.NID))
            {
                int idx = FNID[Msg.NID];
                OrderStatusEnum OrderStatus = (OrderStatusEnum)Enum.Parse(typeof(OrderStatusEnum), showOrderStatuses[idx].OrderStatus, false);
                if (Msg.Data != null) showOrderStatuses[idx].Data = Msg.Data;
                if (OrderStatus != OrderStatusEnum.osQuoteAccept) showOrderStatuses[idx].OrderStatus = OrderStatusEnum.osPendingCancel.ToString();
            }
        }
        //改單傳送中
        void OnPendingReplace(ExecutionReportMessage Msg)
        {
            if (FNID.ContainsKey(Msg.NID))
            {
                int idx = FNID[Msg.NID];
                //FoundRow.UserData = GetTick();
                showOrderStatuses[idx].OrderStatus = OrderStatusEnum.osPendingReplace.ToString();
                if (Msg.Data != null) showOrderStatuses[idx].Data = Msg.Data;
            }
        }
        //成交回報
        void OnPartiallyFilled(string OrderID, long NID, int MatchQty, SideEnum Side, double Price, string Data, string DTime)
        {
            int idx = -1;
            if (FOrdID.ContainsKey(OrderID))
            {
                idx = FOrdID[OrderID];
            }
            else
            {
                if (FNID.ContainsKey(NID)) idx = FNID[NID];
            }
            if (idx != -1)
            {
                if (Data != null) showOrderStatuses[idx].Data = Data;
                if (MatchQty > 0)
                {
                    
                    int Qty = showOrderStatuses[idx].Qty;
                    double Amt = showOrderStatuses[idx].calculate_amt(MatchQty, Price);
                    int CumQty = showOrderStatuses[idx].CumQty + MatchQty;

                    showOrderStatuses[idx].AvgPrice = Math.Round(Amt / CumQty, 2, MidpointRounding.AwayFromZero);
                    showOrderStatuses[idx].CumQty = CumQty;
                    showOrderStatuses[idx].DealTime = DTime;
                    if (Qty == CumQty) ///< Filled
                    {
                        showOrderStatuses[idx].OrderStatus = OrderStatusEnum.osFilled.ToString();
                    }
                    else
                    {
                        showOrderStatuses[idx].OrderStatus = OrderStatusEnum.osPartiallyFilled.ToString();
                    }
                }
            }
        }

        //委託成功
        void OnNewOrder(SpeedyAPI.ExecutionReportMessage Msg)
        {
            if (FNID.ContainsKey(Msg.NID))
            {
                int idx = FNID[Msg.NID];
                OrderStatusEnum OldOrderStatus = (OrderStatusEnum)Enum.Parse(typeof(OrderStatusEnum), showOrderStatuses[idx].OrderStatus, false);
                //FoundRow["Time"] = Msg.MessageDateTime;// System.DateTime.Now.ToString("HH:mm:ss.fff");
                showOrderStatuses[idx].OrderID = Msg.OrderID;
                showOrderStatuses[idx].BrokerID = Msg.BrokerID;
                showOrderStatuses[idx].TradeSession = Msg.TradingSessionID.ToString();
                showOrderStatuses[idx].OrderTime = Msg.TransactTime;
                if (Msg.StatusCode == "31") ///< TWSE Qty Cut
                    showOrderStatuses[idx].Qty = Msg.OrderQty;
                if (OldOrderStatus == OrderStatusEnum.osPendingNew)
                {
                    if (!FOrdID.ContainsKey(Msg.OrderID)) FOrdID.Add(Msg.OrderID, idx);
                    showOrderStatuses[idx].Symbol = Msg.Symbol;
                    showOrderStatuses[idx].Data = Msg.Data;
                    showOrderStatuses[idx].OrderStatus = OrderStatusEnum.osNew.ToString();
                }
            }
            else ///< Order from other people or FIX
            {
                ///< NID not exists
                AddNewRowByNewOrderExecutionReport(Msg);
            }
        }
        //改單
        void OnReplaced(SpeedyAPI.ExecutionReportMessage Msg)
        {
            int idx = -1;
            if (FOrdID.ContainsKey(Msg.OrderID))
            {
                idx = FOrdID[Msg.OrderID];
            }
            else
            {
                if (FNID.ContainsKey(Msg.NID)) idx = FNID[Msg.NID];
            }
            if (idx != -1)
            {
                if (Msg.Data != null) showOrderStatuses[idx].Data = Msg.Data;
                //改價
                if (Msg.IsReplacePx)
                {
                    showOrderStatuses[idx].OrdPrice = Msg.Price;
                    showOrderStatuses[idx].OrderType = Msg.OrderType.ToString();
                    showOrderStatuses[idx].TimeInForce = Msg.TimeInForce.ToString();
                    showOrderStatuses[idx].OrderTime = Msg.TransactTime;
                }
                else //改量
                {
                    int OrderQty = showOrderStatuses[idx].Qty;
                    int CumQty = showOrderStatuses[idx].CumQty;
                    int AfterQty = Msg.LeavesQty;//OrderQty - Msg.OrderQty;;
                    showOrderStatuses[idx].Qty = AfterQty;
                    if (AfterQty - CumQty > 0)
                    {
                        if (CumQty > 0)
                            showOrderStatuses[idx].OrderStatus = OrderStatusEnum.osPartiallyFilled.ToString();
                    }
                    else
                    {
                        if (CumQty > 0) ///< Filled
                        {
                            showOrderStatuses[idx].OrderStatus = OrderStatusEnum.osFilled.ToString();
                        }
                        else ///< Canceled
                        {
                            showOrderStatuses[idx].OrderStatus = OrderStatusEnum.osCanceled.ToString();
                        }
                    }
                }
            }    
        }
        
        void OnCanceled(SpeedyAPI.ExecutionReportMessage Msg)
        {
            int idx = -1;
            if (FOrdID.ContainsKey(Msg.OrderID))
            {
                idx = FOrdID[Msg.OrderID];
            }
            else
            {
                if (FNID.ContainsKey(Msg.NID)) idx = FNID[Msg.NID];
            }
            if (idx != -1)
            {
                int CumQty = showOrderStatuses[idx].CumQty;
                if (Msg.Data != null) showOrderStatuses[idx].Data = Msg.Data;
                if (CumQty == 0)
                {
                    showOrderStatuses[idx].Qty = 0;
                    showOrderStatuses[idx].OrderStatus = OrderStatusEnum.osCanceled.ToString();
                }
                else
                {
                    showOrderStatuses[idx].Qty = CumQty;
                    showOrderStatuses[idx].OrderStatus = OrderStatusEnum.osFilled.ToString();
                }
            }
        }
        //--------------------------------------------------------------------------------------------------------------------------------------------------
        void OnRejected(SpeedyAPI.ExecutionReportMessage Msg)
        {
            int idx = -1;
            if (FNID.ContainsKey(Msg.NID))
            {
                idx = FNID[Msg.NID];
            }
            else
            {
                if (FOrdID.ContainsKey(Msg.OrderID)) idx = FOrdID[Msg.OrderID];
            }
            if (idx != -1)
            {
                showOrderStatuses[idx].Text = string.Copy(Msg.Text);
                switch (Msg.CxlRejResponseTo)
                {
                    case CxlRejResponseToEnum.crrNew:
                    case CxlRejResponseToEnum.crrOrderStatus:
                        showOrderStatuses[idx].OrderStatus = OrderStatusEnum.osRejected.ToString();
                        showOrderStatuses[idx].OrderID = Msg.OrderID;
                        if (!FOrdID.ContainsKey(Msg.OrderID)) FOrdID.Add(Msg.OrderID, idx);
                        break;
                    default:
                        showOrderStatuses[idx].OrderID = Msg.OrderID;
                        if (!FOrdID.ContainsKey(Msg.OrderID)) FOrdID.Add(Msg.OrderID, idx);
                        break;
                }
                if (Msg.Data != null) showOrderStatuses[idx].Data = Msg.Data;
            }
        }
    }
}
