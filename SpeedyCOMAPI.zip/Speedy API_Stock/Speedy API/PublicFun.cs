﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using SpeedyAPI;

namespace Speedy_API
{
    public class TIFCmbItem
    {
        public TIFCmbItem(TimeInForceEnum value, string text)
        {
            Value = value;
            Text = text;
        }
        public TimeInForceEnum Value { get; set; }
        public string Text { get; set; }

        public override string ToString()
        {
            return Text;
        }

    }
    partial class Form1
    {
        public enum TSEOrderTypeEnum
        {
            Normal = 0,
            FinancingSelf = 3,
            ShortSelf = 4
            //白金版不提供5,6, TPASS+ SPEEDY才有
            //SellShort = 5,
            //SellShortEx = 6
        }

        public enum AmendTypeEnum
        {
            amend = 0,
            cancel = 1
        }

        public void amend_func(AmendTypeEnum amendType)
        {
            int idx = dataGridView1.CurrentRow.Index;
            long NID = showOrderStatuses[idx].NID;
            if (NID != 0)
            {
                OrderStatusEnum OrderStatus = (OrderStatusEnum)Enum.Parse(typeof(OrderStatusEnum), showOrderStatuses[idx].OrderStatus, false);
                switch (OrderStatus)
                {
                    case OrderStatusEnum.osNew:
                    case OrderStatusEnum.osPartiallyFilled:
                    case OrderStatusEnum.osReplaced:
                        {
                            switch (amendType)
                            {
                                case AmendTypeEnum.cancel:
                                    {
                                        if (showOrderStatuses[idx].TimeInForce == TimeInForceEnum.tifROD.ToString() && showOrderStatuses[idx].Qty != showOrderStatuses[idx].CumQty && showOrderStatuses[idx].OrderType == OrderTypeEnum.otLimit.ToString())
                                        {
                                            CancelOrderMessage CancelMsg = OrderCancel(showOrderStatuses[idx]);
                                            FOrderConnection.CancelOrder(CancelMsg);
                                        }
                                        break;
                                    }
                                case AmendTypeEnum.amend:
                                    {
                                        ReplaceForm rForm = new ReplaceForm(showOrderStatuses[idx], this);
                                        rForm.Show();
                                    }
                                    break;
                            }
                        }
                        break;
                    default: break;

                }
            }
        }

        public void setCmb()
        {
            cmbMarket.Items.Clear();
            cmbMarket.Items.Add(new MarketCmbItem(MarketEnum.mTSE, MarketEnum.mTSE.ToString()));
            cmbMarket.Items.Add(new MarketCmbItem(MarketEnum.mOTC, MarketEnum.mOTC.ToString()));
            cmbMarket.SelectedIndex = 0;

            cmbSide.Items.Clear();
            cmbSide.Items.Add(new SideCmbItem(SideEnum.sBuy, SideEnum.sBuy.ToString()));
            cmbSide.Items.Add(new SideCmbItem(SideEnum.sSell, SideEnum.sSell.ToString()));
            cmbSide.SelectedIndex = 0;

            cmbTIF.Items.Clear();
            cmbTIF.Items.Add(new TIFCmbItem(TimeInForceEnum.tifROD, TimeInForceEnum.tifROD.ToString()));
            cmbTIF.Items.Add(new TIFCmbItem(TimeInForceEnum.tifIOC, TimeInForceEnum.tifIOC.ToString()));
            cmbTIF.Items.Add(new TIFCmbItem(TimeInForceEnum.tifFOK, TimeInForceEnum.tifFOK.ToString()));
            cmbTIF.SelectedIndex = 0;

            cmbOrdType.Items.Clear();
            cmbOrdType.Items.Add(new OrdTypeCmbItem(OrderTypeEnum.otLimit, OrderTypeEnum.otLimit.ToString()));
            cmbOrdType.Items.Add(new OrdTypeCmbItem(OrderTypeEnum.otMarket, OrderTypeEnum.otMarket.ToString()));
            cmbOrdType.SelectedIndex = 0;

            cmbTSE.Items.Clear();
            cmbTSE.Items.Add(new TSEOrdTypeCmbItem(TSEOrderTypeEnum.Normal, TSEOrderTypeEnum.Normal.ToString()));
            cmbTSE.Items.Add(new TSEOrdTypeCmbItem(TSEOrderTypeEnum.FinancingSelf, TSEOrderTypeEnum.FinancingSelf.ToString())); //自資
            cmbTSE.Items.Add(new TSEOrdTypeCmbItem(TSEOrderTypeEnum.ShortSelf, TSEOrderTypeEnum.ShortSelf.ToString()));         //自券
            cmbTSE.SelectedIndex = 0;

            cmbSession.Items.Clear();
            cmbSession.Items.Add(new SessionCmbItem(TradingSessionIDEnum.tsNormal, TradingSessionIDEnum.tsNormal.ToString()));          //整股
            //cmbSession.Items.Add(new SessionCmbItem(TradingSessionIDEnum.tsIntradayOdd, TradingSessionIDEnum.tsIntradayOdd.ToString()));//盤中零股-白金版不提供
            cmbSession.Items.Add(new SessionCmbItem(TradingSessionIDEnum.tsOffHour, TradingSessionIDEnum.tsOffHour.ToString()));        //定盤
            //cmbSession.Items.Add(new SessionCmbItem(TradingSessionIDEnum.tsOddLot, TradingSessionIDEnum.tsOddLot.ToString()));          //盤後零股-白金版不提供
            cmbSession.SelectedIndex = 0;
        }

        private class MarketCmbItem
        {
            public MarketCmbItem(MarketEnum value, string text)
            {
                Value = value;
                Text = text;
            }
            public MarketEnum Value { get; set; }
            public string Text { get; set; }
            public override string ToString()
            {
                return Text;
            }
        }

        private class SessionCmbItem
        {
            public SessionCmbItem(TradingSessionIDEnum value, string text)
            {
                Value = value;
                Text = text;
            }

            public TradingSessionIDEnum Value { get; set; }
            public string Text { get; set; }

            public override string ToString()
            {
                return Text;
            }
        }

        private class TSEOrdTypeCmbItem
        {
            public TSEOrdTypeCmbItem(TSEOrderTypeEnum value, string text)
            {
                Value = value;
                Text = text;
            }

            public TSEOrderTypeEnum Value { get; set; }
            public string Text { get; set; }
            public override string ToString()
            {
                return Text;
            }
        }

        private class OrdTypeCmbItem
        {
            public OrdTypeCmbItem(OrderTypeEnum value, string text)
            {
                Value = value;
                Text = text;
            }
            public OrderTypeEnum Value { get; set; }
            public string Text { get; set; }
            public override string ToString()
            {
                return Text;
            }
        }

        
        
        private class SideCmbItem
        {
            public SideCmbItem(SideEnum value, string text)
            {
                Value = value;
                Text = text;
            }

            public SideEnum Value { get; set; }
            public string Text { get; set; }

            public override string ToString()
            {
                return Text;
            }

        }
    }
}
